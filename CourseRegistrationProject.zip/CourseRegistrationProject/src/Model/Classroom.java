package Model;

import java.io.Serializable;

public class Classroom implements Serializable {
    /**
     *
     */
    private static final long serialVersionUID = 1L;
    // valid variable and start Pojo
    private String building;

    private String roomNumber;

    private String campus;

    private String type;

    private int capacity;

    public Classroom(String building, String roomNumber, String campus,

                     String type, int capacity) {
        this.building = building;

        this.roomNumber = roomNumber;

        this.campus = campus;

        this.type = type;

        this.capacity = capacity;

    }
    // paramaterized constructor


    // default constructor

    public Classroom() {

        building = "";

        roomNumber = "";

        campus = "";

        type = "";

        capacity = 0;

    }


    //set and get
    public String getBuilding() {
        return building;
    }

    public void setBuilding(String building) {
        this.building = building;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getCampus() {
        return campus;
    }

    public void setCampus(String campus) {
        this.campus = campus;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }
    // make toString function
    public String toString() {

        // returning a string containing all info about the class room

        return "Classroom [ Building: " + building + ", Room Number: " + roomNumber

                + ", Campus: " + campus + ", Type: " + type + ", Capacity: "

                + capacity + "]";

    }



}