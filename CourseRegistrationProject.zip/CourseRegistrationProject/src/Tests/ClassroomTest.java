package Tests;
import java.time.LocalTime;

import Model.Classroom;

public class ClassroomTest {

	public static void main(String[] args) {

		Classroom compSciLab = new Classroom("8", "17", "Ankeny", "Computer Lab", 25);
		String class1 = compSciLab.toString();
		System.out.println(class1);

		Classroom bioLab = new Classroom("3", "28a", "Ankeny", "Science Lab", 22);
		String class2 = bioLab.toString();
		System.out.println(class2);

		Classroom litRoom = new Classroom("2", "12", "Urban", "Classroom", 18);
		String class3 = litRoom.toString();
		System.out.println(class3);

	}

}