package Controller;

import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import Model.Classroom;
import Model.Instructor;

public class InstructorFileHelper implements FileHelper {
	String nameOfFile = "instructor.txt";
	File instructorList = new File(nameOfFile);
	
	@Override
	public boolean doesAFileExist() {
		if (instructorList.exists()) {
			return true;
		} else {
			return false;
		}
	}
		@Override
		public boolean writeFile(ArrayList<?> list) {
		// TODO Auto-generated method stub
		ArrayList<Instructor> InstructorsToWrite = (ArrayList<Instructor>) (list);
		try {
		PrintWriter listOfObjects = new PrintWriter(nameOfFile);
		for (Instructor c : InstructorsToWrite) {
		StringBuilder sb = new StringBuilder();
		sb.append(c.getFirstName() + "," + c.getLastName() + "," +
		c.getEmail());
		listOfObjects.println(sb.toString());
		}
		listOfObjects.close();
		} catch (FileNotFoundException e) {
		System.out.println("No file called " + nameOfFile + " found when writing Instructors.");
		return false;
		}
		return true;
		}
		//continues on next page
		@Override
		public ArrayList<?> readFile() {
		// TODO Auto-generated method stub
		ArrayList<Instructor> allInstructors = new ArrayList<Instructor>();
		Scanner fileIn;
		try {
		fileIn = new Scanner(instructorList);
		while (fileIn.hasNextLine()) {
		String value = fileIn.nextLine();
		String[] parts = value.split(",");
		/*
		* This code block is for you to uncomment if you have errors
		or incorrect data.
		* System.out.println(parts[0]);
		* System.out.println(parts[1]);
		* System.out.println(parts[2]);

		*/
		Instructor currentInstructor = new Instructor(parts[0], parts[1],
		parts[2]);
		allInstructors.add(currentInstructor);
		}
		fileIn.close();
		} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		System.out.println("No file called " + nameOfFile + " found when reading Instructors.");
		}
		return allInstructors;
		}
		}